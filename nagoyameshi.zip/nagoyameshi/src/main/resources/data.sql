/* roles */
INSERT IGNORE INTO roles (id,name) VALUES(1,'ROLE_GENERAL');
INSERT IGNORE INTO roles (id,name) VALUES(2,'ROLE_ADMIN');
/*categories*/
INSERT IGNORE INTO categories (id,category) VALUES(1,'居酒屋');
INSERT IGNORE INTO categories (id,category) VALUES(2,'焼肉');
INSERT IGNORE INTO categories (id,category) VALUES(3,'寿司');
INSERT IGNORE INTO categories (id,category) VALUES(4,'定食');
INSERT IGNORE INTO categories (id,category) VALUES(5,'カレー');
INSERT IGNORE INTO categories (id,category) VALUES(6,'喫茶');
INSERT IGNORE INTO categories (id,category) VALUES(7,'ステーキ');
INSERT IGNORE INTO categories (id,category) VALUES(8,'ハンバーグ');
INSERT IGNORE INTO categories (id,category) VALUES(9,'そば');
INSERT IGNORE INTO categories (id,category) VALUES(10,'スイーツ');
INSERT IGNORE INTO categories (id,category) VALUES(11,'すき焼き');
/*companies*/
INSERT IGNORE INTO companies (id,company,ceo,incorporation,post_code,address,tel,business) VALUES(1,'名古屋飯','名古屋飯太郎','2023/1/1','123-4567','〇〇県〇〇市〇〇','000-123-4567','名古屋飯を運営する会社です。');
/*reservations*/
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(1,1,1,'2024/1/1',1);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(2,2,1,'2024/1/2',2);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(3,3,1,'2024/1/3',1);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(4,4,1,'2024/1/4',2);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(5,5,1,'2024/1/5',1);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(6,6,1,'2024/1/6',2);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(7,7,1,'2024/1/7',1);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(8,8,1,'2024/1/8',2);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(9,9,1,'2024/1/9',1);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(10,10,1,'2024/1/10',2);
INSERT IGNORE INTO reservations (id,user_id,store_id,checkin_date,number) VALUES(11,11,1,'2024/1/11',1);
/*reviews*/
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(1,1,1,1,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(2,2,1,2,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(3,3,1,3,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(4,4,1,4,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(5,5,1,5,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(6,6,1,1,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(7,7,1,2,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(8,8,1,3,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(9,9,1,4,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(10,10,1,5,'テスト');
INSERT IGNORE INTO reviews (id,user_id,store_id,score,content) VALUES(11,11,1,2,'テスト');
/*stores*/
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(1,1,'居酒屋さん','house01.jpg','居酒屋さん',1000,3000,18,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(2,2,'焼肉屋さん','house02.jpg','焼肉屋さん',3000,10000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(3,3,'お寿司屋さん','house03.jpg','お寿司屋さん',3000,10000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(4,4,'定食屋さん','house04.jpg','定食屋さん',500,1500,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(5,5,'カレー屋さん','house05.jpg','カレー屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(6,6,'喫茶','house06.jpg','喫茶',1000,3000,6,18,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(7,7,'ステーキ屋さん','house07.jpg','ステーキ屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(8,8,'ハンバーグ屋さん','house08.jpg','ハンバーグ屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(9,9,'そば屋さん','house09.jpg','そば屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(10,10,'スイーツ屋さん','house10.jpg','スイーツ屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
INSERT IGNORE INTO stores (id,category_id,store_name,image_name,description,price_lower,price_upper,hours_start,hours_end,post_code,address,tel,capacity,holiday) VALUES(11,11,'すき焼き屋さん','house1.jpg','すき焼き屋さん',1000,3000,9,22,'123-4567','〇〇県〇〇市〇〇','000-123-4567',4,'火、水');
/*users*/
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(1,1,'test太郎1','フリガナ','c@nagoyameshi.aa.ab','$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(2,1,'test太郎2','フリガナ','d@nagoyameshi.aa.ab','$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(3,2,'test太郎3','フリガナ','e@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(4,2,'test太郎4','フリガナ','f@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(5,2,'test太郎5','フリガナ','g@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(6,2,'test太郎6','フリガナ','h@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(7,2,'test太郎7','フリガナ','i@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(8,2,'test太郎8','フリガナ','j@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(9,2,'test太郎9','フリガナ','k@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(10,2,'test太郎10','フリガナ','a@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
INSERT IGNORE INTO users (id,role_id,name,furigana,email,password,post_code,address,tel,enabled,user_type) VALUES(11,2,'test太郎11','フリガナ','b@nagoyameshi.aa.ab','password','123-4567','〇〇県〇〇市〇〇','000-123-4567',true,1);
