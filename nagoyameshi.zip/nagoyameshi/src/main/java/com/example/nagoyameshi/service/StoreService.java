package com.example.nagoyameshi.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.form.StoreEditForm;
import com.example.nagoyameshi.form.StoreRegisterForm;
import com.example.nagoyameshi.repository.StoreRepository;

@Service
public class StoreService {
	private final StoreRepository storeRepository;

	public StoreService(StoreRepository storeRepository) {
		this.storeRepository = storeRepository;
	}

	@Transactional
	public void create(StoreRegisterForm storeRegisterForm) {
		Store store = new Store();
		MultipartFile imageFile = storeRegisterForm.getImageFile();

		if (!imageFile.isEmpty()) {
			String imageName = imageFile.getOriginalFilename();
			String hashedImageName = generateNewFileName(imageName);
			Path filePath = Paths.get("src/main/resources/static/storage/" + hashedImageName);
			copyImageFile(imageFile, filePath);
			store.setImageName(hashedImageName);
		}

		store.setCategory(storeRegisterForm.getCategory());
		store.setStoreName(storeRegisterForm.getStoreName());
		store.setDescription(storeRegisterForm.getDescription());
		store.setPriceLower(storeRegisterForm.getPriceLower());
		store.setPriceUpper(storeRegisterForm.getPriceUpper());
		store.setHoursStart(storeRegisterForm.getHoursStart());
		store.setHoursEnd(storeRegisterForm.getHoursEnd());
		store.setPostCode(storeRegisterForm.getPostCode());
		store.setAddress(storeRegisterForm.getAddress());
		store.setTel(storeRegisterForm.getTel());
		store.setCapacity(storeRegisterForm.getCapacity());
		store.setHoliday(storeRegisterForm.getHoliday());

		storeRepository.save(store);
	}

    @Transactional
    public void update(StoreEditForm storeEditForm) {
        Store store = storeRepository.getReferenceById(storeEditForm.getId());
        MultipartFile imageFile = storeEditForm.getImageFile();
        
        if (!imageFile.isEmpty()) {
            String imageName = imageFile.getOriginalFilename(); 
            String hashedImageName = generateNewFileName(imageName);
            Path filePath = Paths.get("src/main/resources/static/storage/" + hashedImageName);
            copyImageFile(imageFile, filePath);
            store.setImageName(hashedImageName);
        }
        
		store.setCategory(storeEditForm.getCategory());
		store.setStoreName(storeEditForm.getStoreName());
		store.setDescription(storeEditForm.getDescription());
		store.setPriceLower(storeEditForm.getPriceLower());
		store.setPriceUpper(storeEditForm.getPriceUpper());
		store.setHoursStart(storeEditForm.getHoursStart());
		store.setHoursEnd(storeEditForm.getHoursEnd());
		store.setPostCode(storeEditForm.getPostCode());
		store.setAddress(storeEditForm.getAddress());
		store.setTel(storeEditForm.getTel());
		store.setCapacity(storeEditForm.getCapacity());
		store.setHoliday(storeEditForm.getHoliday());
                    
        storeRepository.save(store);
    }

	// UUIDを使って生成したファイル名を返す
	public String generateNewFileName(String fileName) {
		String[] fileNames = fileName.split("\\.");
		for (int i = 0; i < fileNames.length - 1; i++) {
			fileNames[i] = UUID.randomUUID().toString();
		}
		String hashedFileName = String.join(".", fileNames);
		return hashedFileName;
	}

	// 画像ファイルを指定したファイルにコピーする
	public void copyImageFile(MultipartFile imageFile, Path filePath) {
		try {
			Files.copy(imageFile.getInputStream(), filePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}