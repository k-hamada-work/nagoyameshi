package com.example.nagoyameshi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.nagoyameshi.entity.Reservation;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {

}