package com.example.nagoyameshi.form;

import java.time.LocalTime;

import org.springframework.web.multipart.MultipartFile;

import com.example.nagoyameshi.entity.Category;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class StoreRegisterForm {
    @NotBlank(message = "店舗名を入力してください。")
    private String storeName;

    private MultipartFile imageFile;
    
    @NotBlank(message = "説明を入力してください。")
    private String description;   

    @NotNull(message = "カテゴリを選択してください。")
    private Category category;
    
    @NotNull(message = "料金の下限を入力してください。")
    @Min(value = 1, message = "宿泊料金は1円以上に設定してください。")
    private Integer priceLower;

    @NotNull(message = "料金の上限を入力してください。")
    @Min(value = 1, message = "宿泊料金は1円以上に設定してください。")
    private Integer priceUpper;

    @NotNull(message = "営業開始時間を選択してください。")
    private LocalTime hoursStart;

    @NotNull(message = "営業終了時間を選択してください。")
    private LocalTime hoursEnd;

    @NotNull(message = "定員を選択してください。")
    @Min(value = 1, message = "定員は1人以上に設定してください。")
    private Integer capacity;     
    
    @NotBlank(message = "郵便番号を入力してください。")
    private String postCode;
    
    @NotBlank(message = "住所を入力してください。")
    private String address;
    
    @NotBlank(message = "電話番号を入力してください。")
    private String tel;

    @NotBlank(message = "定休日を入力してください。")
    private String holiday;

}
